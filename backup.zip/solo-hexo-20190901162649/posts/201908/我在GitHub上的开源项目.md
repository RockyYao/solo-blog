title: 我在 GitHub 上的开源项目
date: '2019-08-29 16:16:49'
updated: '2019-08-29 16:19:55'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [pay](https://github.com/RockyYao/pay) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/RockyYao/pay/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/RockyYao/pay/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/RockyYao/pay/network/members "分叉数")</span>

支付项目



---

### 2. [Springboot-quick-demo](https://github.com/RockyYao/Springboot-quick-demo) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/RockyYao/Springboot-quick-demo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/RockyYao/Springboot-quick-demo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/RockyYao/Springboot-quick-demo/network/members "分叉数")</span>

平时遇到的DEMO



---

### 3. [bluecat](https://github.com/RockyYao/bluecat) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/RockyYao/bluecat/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/RockyYao/bluecat/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/RockyYao/bluecat/network/members "分叉数")</span>

bolg 源码



---

### 4. [MachiningTracking](https://github.com/RockyYao/MachiningTracking) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/RockyYao/MachiningTracking/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/RockyYao/MachiningTracking/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/RockyYao/MachiningTracking/network/members "分叉数")</span>





---

### 5. [com.Blog-server](https://github.com/RockyYao/com.Blog-server) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/RockyYao/com.Blog-server/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/RockyYao/com.Blog-server/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/RockyYao/com.Blog-server/network/members "分叉数")</span>





---

### 6. [Vue-Blog](https://github.com/RockyYao/Vue-Blog) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/RockyYao/Vue-Blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/RockyYao/Vue-Blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/RockyYao/Vue-Blog/network/members "分叉数")</span>





---

### 7. [index](https://github.com/RockyYao/index) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/RockyYao/index/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/RockyYao/index/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/RockyYao/index/network/members "分叉数")</span>

Blog首页



---

### 8. [label-programmer](https://github.com/RockyYao/label-programmer) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/RockyYao/label-programmer/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/RockyYao/label-programmer/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/RockyYao/label-programmer/network/members "分叉数")</span>

注塑标签打印

